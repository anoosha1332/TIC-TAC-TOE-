﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace problem_2._2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public string current_player { get; set; } = "O";

        private const string X = "X";
        private const string O = "O";

        private string ansX="",ansO="";

        public void swapPlayer()
        {
            if (current_player == "O")
                current_player = "X";
            else
                current_player = "O";
        }

        public int logicForX()
        {
            MessageBoxResult result,exitW;

            // horizontal win
            if ((btn1.Content == "X" && btn2.Content == "X" && btn3.Content == "X") || (btn4.Content == "X" && btn5.Content == "X" && btn6.Content == "X") || (btn7.Content == "X" && btn8.Content == "X" && btn9.Content == "X"))
            {
                result = MessageBox.Show("Player 2 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                a=0;
                return a;
            }

            // vertical win
            else if ((btn1.Content == "X" && btn4.Content == "X" && btn7.Content == "X") || (btn2.Content == "X" && btn5.Content == "X" && btn8.Content == "X") || (btn3.Content == "X" && btn6.Content == "X" && btn9.Content == "X"))
            {
                result = MessageBox.Show("Player 2 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                a = 0;
                return a;
            }

            // left diagonal
            else if (btn1.Content == "X" && btn5.Content == "X" && btn9.Content == "X")
            {
                result = MessageBox.Show("Player 2 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                a = 0;
                return a;
            }

            // right diagonal
            else if (btn3.Content == "X" && btn5.Content == "X" && btn7.Content == "X")
            {
                result = MessageBox.Show("Player 2 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                a = 0;
                return a;
            }
            a = 1;
            return a;
        }

        int a =-1,b=-1;
        public int logicForO()
        {
            MessageBoxResult result, exitW;

            // horizontal win
            if ((btn1.Content == "O" && btn2.Content == "O" && btn3.Content == "O") || (btn4.Content == "O" && btn5.Content == "O" && btn6.Content == "O") || (btn7.Content == "O" && btn8.Content == "O" && btn9.Content == "O"))
            {
                result = MessageBox.Show("Player 1 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                b = 0;
                return b;
            }

            // vertical win
            else if ((btn1.Content == "O" && btn4.Content == "O" && btn7.Content == "O") || (btn2.Content == "O" && btn5.Content == "O" && btn8.Content == "O") || (btn3.Content == "O" && btn6.Content == "O" && btn9.Content == "O"))
            {
                result = MessageBox.Show("Player 1 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                b = 0;
                return b;
            }

            // left diagonal
            else if (btn1.Content == "O" && btn5.Content == "O" && btn9.Content == "O")
            {
                result = MessageBox.Show("Player 1 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                b = 0;
                return b;
            }

            // right diagonal
            else if (btn3.Content == "O" && btn5.Content == "O" && btn7.Content == "O")
            {
                result = MessageBox.Show("Player 1 WINS");
                exitW = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
                b = 0;
                return b;
            }
            b = 1;
            return b;
        }

        public void tie()
        {
            MessageBoxResult result;
            result = MessageBox.Show("There is a TIE");
            result = MessageBox.Show("Select EXIT or NEW GAME from Main Menu. Thanks!!");
 
        }
        int c = 1;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            btn.Content = current_player;
           
            swapPlayer();

            //logicForO();
            //logicForX();

            
            if (logicForO() == 1)
            {
                if (logicForX() == 1)
                {
                    a = 2;
                    c++;
                }
            }
            if (a==2 && c==9)
                tie();
        }

        private void Button_Click_newGame(object sender, RoutedEventArgs e)
        {
            current_player = "O";
            btn1.Content = "";
            btn2.Content = "";
            btn3.Content = "";

            btn4.Content = "";
            btn5.Content = "";
            btn6.Content = "";

            btn7.Content = "";
            btn8.Content = "";
            btn9.Content = "";

            c = 1;
        }

        private void Button_Click_exit(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);
            c = 1;
        }
    }
}
